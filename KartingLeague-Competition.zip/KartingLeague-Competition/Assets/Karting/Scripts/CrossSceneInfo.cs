public static class CrossSceneInfo
{
    public static string Round { get; set; }
}